package com.project.vedantra.vedantra_ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VedantraAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(VedantraAiApplication.class, args);
    }

}
